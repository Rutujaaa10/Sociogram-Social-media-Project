function show(){
    var alert = document.getElementById('msg-card');
    alert.style.display="block";
}

